class Incompatible(Exception):
    pass


class InvalidArguments(Exception):
    pass


class PipError(Exception):
    pass
